> 参考サイト
> https://www.gatsbyjs.org/tutorial/part-four/

## ギャツビーのデータ

ウェブサイトには、HTML、CSS、JS、データの 4 つの部分があります。

### データとは

データとは、**「文字列」**、整数(**42**)、オブジェクト(**{ pizza: true }**)などのことです。

しかし、Gatsby で作業する目的のためには、より有用な答えは「**React コンポーネントの外にあるすべてのもの**」です。

<details><summary>説明</summary>これまでは、コンポーネント内で直接テキストを書いたり、画像を追加したりしていましたね。これは多くのウェブサイトを構築するための優れた方法です。しかし、多くの場合、データをコンポーネントの外に保存し、必要に応じてコンポーネントにデータを持ち込みたいと思うでしょう。

WordPress と Gatsby を使ってサイトを構築している場合、サイトのデータ（ページや記事）は WordPress にあり、必要に応じてそのデータをコンポーネントに取り込むことができます。

データは Markdown や CSV などのファイル形式や、データベースや API などあらゆる種類のものにも対応しています。

Gatsby のデータレイヤーを使用すると、これらのデータ（およびその他のソース）からデータを直接コンポーネントに取り込むことができます。</details>

---

## 構造化されていないデータを使う vs GraphQL

<details><summary>ギャツビーサイトにデータを取り込むには、GraphQL やソースプラグインを使用しなければならないのでしょうか？</summary>

そんなことは決してありません。ノードの createPages API を使用して、**構造化されていないデータ**を GraphQL データレイヤーを経由するのではなく、直接 Gatsby ページに引き込むこともできます。これは小規模なサイトには最適な選択ですが、より複雑なサイトでは GraphQL とソースプラグインを使用することで時間を節約することができます。

[Using Gatsby without GraphQL ガイド](https://www.gatsbyjs.org/docs/using-gatsby-without-graphql/)を参照して、ノードの createPages API を使用して Gatsby サイトにデータを取り込む方法とサイトの例をご覧ください。</details>

---

### 非構造化データと GraphQL はいつ使用しますか？

<details><summary>まあGraphQLつかっとけ</summary>
小規模なサイトを構築している場合、このガイドで説明したように、createPages API を使用して非構造化データを取り込むのが効率的な構築方法の 1 つで、後にサイトが複雑になった場合、より複雑なサイトの構築に移行するか、データを変換したい場合は、以下の手順に従います。

1. プラグインライブラリをチェックして、使いたいソースプラグインやトランスフォーマープラグインがすでに存在するかどうかを確認してください。

2. もし存在しない場合は、プラグインオーサリングガイドを読んで、自分のものを作ることを検討してみてくだ
</details>

---

### ギャツビーのデータ層が GraphQL を使ってデータをコンポーネントに引き込む方法

<details><summary>GraphQLについて</summary>
React コンポーネントにデータを読み込むためのオプションはたくさんあります。その中でも最も人気があり、強力なものの 1 つが GraphQL と呼ばれる技術です。

GraphQL は、プロダクトエンジニアが必要なデータをコンポーネントに引き込むのを支援するために Facebook で発明されました。

GraphQL はクエリ言語（名前の QL の部分）です。SQL に精通している場合、それは非常に似た方法で動作します。特別な構文を使って、コンポーネントに必要なデータを記述すると、そのデータが提供されます。

Gatsby は GraphQL を使用して、コンポーネントが必要なデータを宣言できるようにしています。

</details>

<br>
<br>

---

# 新しいサンプルサイトを作成する

<details><summary>チュートリアルのこの部分のために、別の新しいサイトを作成します。</summary>あなたは、"Pandas Eating Lots "と呼ばれる Markdown ブログを作成します。これは、たくさんの食べ物を食べるパンダの最高の写真とビデオを披露することに専念しています。途中、あなたは GraphQL と Gatsby の Markdown サポートに足を踏み入れます。

新しいターミナルウィンドウを開き、以下のコマンドを実行して、tutorial-part-four というディレクトリに新しい Gatsby サイトを作成してください。そして、新しいディレクトリに移動します。</details>

サンプルサイトをダウンロードしてくる

```powershell
gatsby new tutorial-part-four https://github.com/gatsbyjs/gatsby-starter-hello-world
cd tutorial-part-four
```

そして、プロジェクトのルートに他に必要な依存関係をいくつかインストールします。Typography テーマ「Kirkham」を使用し、CSS-in-JS ライブラリ「Emotion」を試してみます。

```powershell
npm install --save gatsby-plugin-typography typography react-typography typography-theme-kirkham gatsby-plugin-emotion @emotion/core

```

パート 3 で終了したものと同じようなサイトを設定します。このサイトにはレイアウトコンポーネントと 2 つのページコンポーネントがあります。

src/components/layout.js

```javascript
import React from "react";
import { css } from "@emotion/core";
import { Link } from "gatsby";

import { rhythm } from "../utils/typography";

export default function Layout({ children }) {
  return (
    <div
      css={css`
        margin: 0 auto;
        max-width: 700px;
        padding: ${rhythm(2)};
        padding-top: ${rhythm(1.5)};
      `}
    >
      <Link to={`/`}>
        <h3
          css={css`
            margin-bottom: ${rhythm(2)};
            display: inline-block;
            font-style: normal;
          `}
        >
          Pandas Eating Lots
        </h3>
      </Link>
      <Link
        to={`/about/`}
        css={css`
          float: right;
        `}
      >
        About
      </Link>
      {children}
    </div>
  );
}
```

src/pages/index.js

```javascript
import React from "react";
import Layout from "../components/layout";

export default function Home() {
  return (
    <Layout>
      <h1>Amazing Pandas Eating Things</h1>
      <div>
        <img
          src="https://2.bp.blogspot.com/-BMP2l6Hwvp4/TiAxeGx4CTI/AAAAAAAAD_M/XlC_mY3SoEw/s1600/panda-group-eating-bamboo.jpg"
          alt="Group of pandas eating bamboo"
        />
      </div>
    </Layout>
  );
}
```

src/pages/about.js

```javascript
import React from "react";
import Layout from "../components/layout";

export default function About() {
  return (
    <Layout>
      <h1>About Pandas Eating Lots</h1>
      <p>
        We're the only site running on your computer dedicated to showing the
        best photos and videos of pandas eating lots of food.
      </p>
    </Layout>
  );
}
```

src/utils/typography.js

```javascript
import Typography from "typography";
import kirkhamTheme from "typography-theme-kirkham";

const typography = new Typography(kirkhamTheme);

export default typography;
export const rhythm = typography.rhythm;
```

gatsby-config.js (src 以下ではなく、プロジェクトのルートになければなりません)

gatsby-config.js

```javascript
module.exports = {
  plugins: [
    `gatsby-plugin-emotion`,
    {
      resolve: `gatsby-plugin-typography`,
      options: {
        pathToConfigModule: `src/utils/typography`,
      },
    },
  ],
};
```

上記のファイルを追加して、いつものように gatsby develop を実行すると、以下のように表示されるはずです。

![画像](https://www.gatsbyjs.org/static/9a136a7536d2f4b315d446f6a1a83725/ca3c3/start.png)
レイアウトと 2 ページの小さなサイトをもう一つ持っていますね。

これで、クエリを開始することができるようになりました 😋。

# 最初のグラフ QL クエリ

サイトを構築する際には、例えばサイトタイトルのような共通のデータを再利用したいと思うでしょう。about/ページを見てください。レイアウトコンポーネント（サイトヘッダー）と about.js ページの`<h1/>`
（ページヘッダー）の両方にサイトタイトル（Pandas Eating Lots）があることに気づくでしょう。

しかし、将来的にサイトタイトルを変更したい場合はどうでしょうか？すべてのコンポーネントでタイトルを検索し、各インスタンスを編集しなければなりません。これは、特に大規模で複雑なサイトでは、面倒でエラーが発生しやすい作業です。代わりに、タイトルを一つの場所に保存し、他のファイルからその場所を参照することができます。タイトルを一つの場所で変更すれば、Gatsby は更新されたタイトルを参照するファイルに引き込んでくれます。

これらの共通のデータを格納する場所は、gatsby-config.js ファイル内の siteMetadata オブジェクトです。gatsby-config.js ファイルにサイトタイトルを追加します。
gatsby-config.js

```javascript
module.exports = {
  siteMetadata: {
    title: `Title from siteMetadata`,
  },
  plugins: [
    `gatsby-plugin-emotion`,
    {
      resolve: `gatsby-plugin-typography`,
      options: {
        pathToConfigModule: `src/utils/typography`,
      },
    },
  ],
};
```

開発サーバーを再起動してください。

---

## ページクエリを使用する

これでサイトのタイトルがクエリで取得できるようになりました。

src/pages/about.js

```javascript
import React from "react";
import { graphql } from "gatsby";
import Layout from "../components/layout";

export default function About({ data }) {
  return (
    <Layout>
      <h1>About {data.site.siteMetadata.title}</h1>
      <p>
        We're the only site running on your computer dedicated to showing the
        best photos and videos of pandas eating lots of food.
      </p>
    </Layout>
  );
}

export const query = graphql`
  query {
    site {
      siteMetadata {
        title
      }
    }
  }
`;
```

上手くいった！！！！！！！！！！！！！！！（笑 🎉
![画像](https://www.gatsbyjs.org/static/4df7cdfeb994c1a07b4557f0f6010d91/c5bb3/site-metadata-title.png)  
上記の about.js の変更点でタイトルを取得する基本的な GraphQL クエリは以下の通りです。

src/pages/about.js

```
{
  site {
    siteMetadata {
      title
    }
  }
}
```

ページクエリはコンポーネントの定義の外にあり、慣習的にはページコンポーネントファイルの最後にあります。

---

## StaticQuery を使用する

StaticQuery は Gatsby v2 で導入された新しい API で、ページ以外のコンポーネント（layout.js コンポーネントなど）から GraphQL クエリを使ってデータを取得することができます。ここでは、新しく導入されたフックのバージョンである useStaticQuery を使ってみましょう。

src/components/layout.js ファイルに変更を加えて、useStaticQuery フックと{data.site.siteMetadata.title}を使用するようにします。参照を使用しています。完了すると、ファイルは以下のようになります。
src/components/layout.js

```javascript
import React from "react";
import { css } from "@emotion/core";
import { useStaticQuery, Link, graphql } from "gatsby";

import { rhythm } from "../utils/typography";
export default function Layout({ children }) {
  const data = useStaticQuery(
    graphql`
      query {
        site {
          siteMetadata {
            title
          }
        }
      }
    `
  );
  return (
    <div
      css={css`
        margin: 0 auto;
        max-width: 700px;
        padding: ${rhythm(2)};
        padding-top: ${rhythm(1.5)};
      `}
    >
      <Link to={`/`}>
        <h3
          css={css`
            margin-bottom: ${rhythm(2)};
            display: inline-block;
            font-style: normal;
          `}
        >
          {data.site.siteMetadata.title}
        </h3>
      </Link>
      <Link
        to={`/about/`}
        css={css`
          float: right;
        `}
      >
        About
      </Link>
      {children}
    </div>
  );
}
```

またしても成功！！！！！！！！！！！！！！！（笑

![画像](https://www.gatsbyjs.org/static/500fd2f12d69813d2bbe6d669eaf3ce8/8ce52/site-metadata-two-titles.png)  
なぜここで 2 つの異なるクエリを使うのでしょうか？これらの例では、クエリの種類、書式、使用可能な場所を簡単に紹介しました。今のところ、ページクエリを作成できるのはページのみであることを覚えておいてください。Layout などのページ以外のコンポーネントでは StaticQuery を使用することができます。これらについては、チュートリアルのパート 7 で詳しく説明しています。

でも、本当のタイトルを復活させましょう。

ギャツビーの核となる原則の 1 つは、クリエイターは自分が作っているものとすぐにつながることを必要としているということです（ブレット・ビクターに脱帽）。言い換えれば、コードに何か変更を加えたときには、その変更の効果をすぐに見るべきだということです。ギャツビーの入力を操作すると、新しい出力が画面に表示されます。

つまり、ほとんどの場合、変更した内容はすぐに反映されるということです。gatsby-config.js ファイルを再度編集し、今度はタイトルを "Pandas Eating Lots "に変更します。この変更は、あなたのサイトのページにすぐに反映されるはずです。

![画像](https://www.gatsbyjs.org/static/550fbd5e51d2ec54cad87687acb76a06/c5bb3/pandas-eating-lots-titles.png)

# 次は何が来るの？

次に、チュートリアルのパート 5 では、ソースプラグインを使って GraphQL を使って Gatsby サイトにデータを取り込む方法を学びます。

https://www.gatsbyjs.org/tutorial/part-five/
