> 参考サイト
> https://www.gatsbyjs.org/tutorial/part-seven/

# プログラムでデータからページを作成する

<details><summary>このチュートリアルの内容は？</summary>前のチュートリアルでは、マークダウンファイルをクエリし、ブログ記事のタイトルと抜粋のリストを生成する素敵なインデックスページを作成しました。しかし、単に抜粋を見たいのではなく、マークダウンファイルの実際のページが欲しいのです。

src/pages に React コンポーネントを配置することでページを作成し続けることができます。しかし、ここではデータからページをプログラム的に作成する方法を学びます。Gatsby は、多くの静的サイトジェネレータのようにファイルからページを作成することに限定されていません。Gatsby では、GraphQL を使ってデータをクエリし、クエリ結果をページにマッピングすることができます。これは本当に強力なアイデアです。このチュートリアルの残りの部分では、その意味合いや使い方を探っていきます。

さあ、始めましょう。

</details>

## ページ用のスラッグの作成

「スラッグ」とは、ウェブアドレスのユニークな識別部分のことで、例えば、https://www.gatsbyjs.org/tutorial/part-seven/ ページの /tutorial/part-seven のようなものです。

これは「パス」とも呼ばれますが、このチュートリアルでは一貫性を保つために「スラッグ」という用語を使います。

新しいページの作成には 2 つのステップがあります。

1. ページの「パス」または「スラッグ」を生成する。

2. ページを作成します。

**注意**: 多くの場合、データソースはコンテンツのスラッグやパス名を直接提供します - それらのシステム（CMS など）で作業する場合、マークダウンファイルで行うようにスラッグを自分で作成する必要はありません。

マークダウンページを作成するために、2 つの Gatsby API を使用することを学びます: onCreateNode と createPages です。これらは多くのサイトやプラグインで使用されている 2 つの API です。

Gatsby API の実装が簡単になるように最善を尽くしています。API を実装するには、gatsby-node.js から API 名を指定した関数をエクスポートします。

そこで、以下のようにします。サイトのルートに、gatsby-node.js というファイルを作成します。そして、以下のように追加します。

gatsby-node.js

```js
exports.onCreateNode = ({ node }) => {
  console.log(node.internal.type);
};
```

この onCreateNode 関数は、新しいノードが作成（または更新）されるたびに、Gatsby によって呼び出されます。

開発サーバを停止して再起動します。そうすると、新しく作成されたノードがターミナルコンソールにかなりの数ログに記録されるのがわかるでしょう。

次のセクションでは、MarkdownRemark ノードに Markdown ページ用のプラグを追加するためにこの API を使用します。

MarkdownRemark ノードのみをログに記録するように関数を変更します。

gatsby-node.js

```js
exports.onCreateNode = ({ node }) => {
  if (node.internal.type === `MarkdownRemark`) {
    console.log(node.internal.type);
  }
};
```

それぞれのマークダウンファイル名を使ってページスラッグを作成したいと思います。そのため、pandas-and-bananas.md は/pandas-and-bananas/になります。しかし、どのようにして MarkdownRemark ノードからファイル名を取得するのでしょうか? ファイルノードにはディスク上のファイルについて必要なデータが含まれているので、それを取得するには、"ノードグラフ "を親のファイルノードまで辿る必要があります。これを行うには、getNode() ヘルパーを使用します。これを onCreateNode の関数パラメータに追加し、それを呼び出してファイルノードを取得します。
gatsby-node.js

```js
exports.onCreateNode = ({ node, getNode }) => {
  if (node.internal.type === `MarkdownRemark`) {
    const fileNode = getNode(node.parent);
    console.log(`\n`, fileNode.relativePath);
  }
};
```

開発サーバーを再起動した後、2 つのマークダウンファイルの相対パスがターミナル画面に表示されるのがわかるはずです。

![画像](https://www.gatsbyjs.org/static/01e3ab44062c37f7f8c749101e8b8915/d72ec/markdown-relative-path.png)

ここで、スラッグを作成する必要があります。ファイル名からスラッグを作成するロジックは厄介なので、 gatsby-source-filesystem プラグインにはスラッグを作成するための関数が同梱されています。それを使ってみましょう。

gatsby-node.js

```js
const { createFilePath } = require(`gatsby-source-filesystem`);

exports.onCreateNode = ({ node, getNode }) => {
  if (node.internal.type === `MarkdownRemark`) {
    console.log(createFilePath({ node, getNode, basePath: `pages` }));
  }
};
```

この関数は、スラッグの作成と一緒に親ファイルノードを見つける処理を行います。開発サーバーを再度実行すると、ターミナルに 2 つのスラッグがログに記録されているのがわかるはずです。

これで、新しいスラッグを MarkdownRemark ノードに直接追加することができます。ノードに追加したデータは後で GraphQL を使ってクエリすることができるので、これは強力です。ページを作成するときにスラッグを簡単に取得できます。

そのためには、API の実装に渡される createNodeField という関数を使用します。この関数を使うと、他のプラグインが作成したノードに追加のフィールドを作成することができます。ノードのオリジナルの作成者のみが直接ノードを変更できます。他のすべてのプラグイン（gatsby-node.js を含む）は、この関数を使用して追加フィールドを作成しなければなりません。

gatsby-node.js

```js
const { createFilePath } = require(`gatsby-source-filesystem`);
exports.onCreateNode = ({ node, getNode, actions }) => {
  const { createNodeField } = actions;
  if (node.internal.type === `MarkdownRemark`) {
    const slug = createFilePath({ node, getNode, basePath: `pages` });
    createNodeField({
      node,
      name: `slug`,
      value: slug,
    });
  }
};
```

開発サーバーを再起動し、GraphiQL を開くか更新します。次に、この GraphQL クエリを実行して、新しいスラッグを確認します。

```
{
  allMarkdownRemark {
    edges {
      node {
        fields {
          slug
        }
      }
    }
  }
}
```

これで slugs「スラッグ」 ができたので、ページを作成します。

# ページを作成する

同じ gatsby-node.js ファイルの中に、以下を追加します。

gatsby-node.js

```js
const { createFilePath } = require(`gatsby-source-filesystem`);

exports.onCreateNode = ({ node, getNode, actions }) => {
  const { createNodeField } = actions;
  if (node.internal.type === `MarkdownRemark`) {
    const slug = createFilePath({ node, getNode, basePath: `pages` });
    createNodeField({
      node,
      name: `slug`,
      value: slug,
    });
  }
};

exports.createPages = async ({ graphql, actions }) => {
  // **Note:** The graphql function call returns a Promise
  // see: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise for more info
  const result = await graphql(`
    query {
      allMarkdownRemark {
        edges {
          node {
            fields {
              slug
            }
          }
        }
      }
    }
  `);
  console.log(JSON.stringify(result, null, 4));
};
```

プラグインがページを追加できるように、Gatsby が呼び出す createPages API の実装を追加しました。

チュートリアルのこの部分のイントロダクションで述べたように、プログラムでページを作成する手順は以下の通りです。

1. GraphQL でデータを問い合わせる
2. クエリ結果をページにマップする

上記のコードは、作成したマークダウンスラッグをクエリするために付属の graphql 関数を使用しているので、マークダウンからページを作成するための最初のステップです。次に、次のようなクエリの結果をログアウトします。

![画像](https://www.gatsbyjs.org/static/5193a6c95058806213c59a7bcf73d526/d72ec/query-markdown-slugs.png)

ページを作成するためには、スラッグの他にもう一つ必要なものがあります。Gatsby のすべてのものと同様に、プログラマティックなページは React コンポーネントによって駆動されます。ページを作成する際には、どのコンポーネントを使用するかを指定する必要があります。

src/templates にディレクトリを作成し、src/templates/blog-post.js という名前のファイルに以下を追加します。

src/templates/blog-post.js

```jsx
import React from "react";
import Layout from "../components/layout";

export default function BlogPost() {
  return (
    <Layout>
      <div>Hello blog post</div>
    </Layout>
  );
}
```

そして、gatsby-node.js を更新します。

gatsby-node.js

```jsx
const path = require(`path`);
const { createFilePath } = require(`gatsby-source-filesystem`);

exports.onCreateNode = ({ node, getNode, actions }) => {
  const { createNodeField } = actions;
  if (node.internal.type === `MarkdownRemark`) {
    const slug = createFilePath({ node, getNode, basePath: `pages` });
    createNodeField({
      node,
      name: `slug`,
      value: slug,
    });
  }
};

exports.createPages = async ({ graphql, actions }) => {
  const { createPage } = actions;
  const result = await graphql(`
    query {
      allMarkdownRemark {
        edges {
          node {
            fields {
              slug
            }
          }
        }
      }
    }
  `);

  result.data.allMarkdownRemark.edges.forEach(({ node }) => {
    createPage({
      path: node.fields.slug,
      component: path.resolve(`./src/templates/blog-post.js`),
      context: {
        // Data passed to context is available
        // in page queries as GraphQL variables.
        slug: node.fields.slug,
      },
    });
  });
};
```

開発サーバーを再起動するとページが作成されます。開発中に作成した新しいページを見つける簡単な方法は、ランダムなパスに行くことです。http://localhost:8000/sdf に行けば、あなたが作成した新しいページが表示されます。

![画像](https://www.gatsbyjs.org/static/b1a3666651a4de0eaf754938d4c9e4fb/d72ec/new-pages.png)

そのうちの 1 つを訪問して、あなたが見る。

![画像](https://www.gatsbyjs.org/static/3467d825ce4845fabbec061e8130e0a8/d72ec/hello-world-blog-post.png)

どちらがいいかというと、ちょっとつまらないし、あなたが望むものではありません。これで、マークダウン投稿からデータを取り込めるようになりました。src/templates/blog-post.js を変更します。

src/templates/blog-post.js

```jsx
import React from "react";
import { graphql } from "gatsby";
import Layout from "../components/layout";

export default function BlogPost({ data }) {
  const post = data.markdownRemark;
  return (
    <Layout>
      <div>
        <h1>{post.frontmatter.title}</h1>
        <div dangerouslySetInnerHTML={{ __html: post.html }} />
      </div>
    </Layout>
  );
}

export const query = graphql`
  query($slug: String!) {
    markdownRemark(fields: { slug: { eq: $slug } }) {
      html
      frontmatter {
        title
      }
    }
  }
`;
```

で、

![画像](https://www.gatsbyjs.org/static/d91348f58c91ccc92588a68be507b324/d72ec/blog-post.png)

スウィート!

最後のステップは、インデックスページから新しいページにリンクすることです。

src/pages/index.js に戻り、マークダウンスラッグをクエリしてリンクを作成します。

src/pages/index.js

```jsx
import React from "react"
import { css } from "@emotion/core"
import { Link, graphql } from "gatsby"
import { rhythm } from "../utils/typography"
import Layout from "../components/layout"

export default function Home({ data }) {
  return (
    <Layout>
      <div>
        <h1
          css={css`
            display: inline-block;
            border-bottom: 1px solid;
          `}
        >
          Amazing Pandas Eating Things
        </h1>
        <h4>{data.allMarkdownRemark.totalCount} Posts</h4>
        {data.allMarkdownRemark.edges.map(({ node }) => (
          <div key={node.id}>
            <Link
              to={node.fields.slug}
              css={css`
                text-decoration: none;
                color: inherit;
              `}
            >
              <h3
                css={css`
                  margin-bottom: ${rhythm(1 / 4)};
                `}
              >
                {node.frontmatter.title}{" "}
                <span
                  css={css`
                    color: #555;
                  `}
                >
                  — {node.frontmatter.date}
                </span>
              </h3>
              <p>{node.excerpt}</p>
            </Link>
          </div>
        ))}
      </div>
    </Layout>
  )
}

export const query = graphql`
  query {
    allMarkdownRemark(sort: { fields: [frontmatter___date], order: DESC }) {
      totalCount
      edges {
        node {
          id
          frontmatter {
            title
            date(formatString: "DD MMMM, YYYY")
          }
          fields {
            slug
          }
          excerpt
        }
      }
    }
  }

```

そして、そこには、あなたが行く! 小さくても働くブログ!

# 挑戦

サイトでもっと遊んでみてください。いくつかの Markdown ファイルを追加してみてください。MarkdownRemark ノードから他のデータをクエリして、フロントページやブログ記事ページに追加してみてください。

チュートリアルのこの部分では、Gatsby のデータレイヤーを使ったビルドの基礎を学びました。プラグインを使用してデータをソース化して変換する方法、GraphQL を使用してデータをページにマッピングする方法、そして各ページのデータをクエリするページテンプレートコンポーネントを構築する方法を学びました。

# 次は何が来るの？
