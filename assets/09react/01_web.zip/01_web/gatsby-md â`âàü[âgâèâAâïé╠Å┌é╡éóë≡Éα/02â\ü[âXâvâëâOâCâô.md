> 参考サイト
> https://www.gatsbyjs.org/tutorial/part-five/

## ソースプラグイン

このチュートリアルでは、GraphQL とソースプラグインを使用して Gatsby サイトにデータを取り込む方法について学習します。ただし、これらのプラグインについて学ぶ前に、クエリを正しく構成するのに役立つツールである GraphiQL と呼ばれるものの使用方法を知っておく必要があります。

### GraphiQL の紹介

<details><summary>紹介</summary>GraphiQLはGraphQL統合開発環境（IDE）です。これは、Gatsbyのウェブサイトを構築する際によく使うパワフルな（そして万能な）ツールです。

あなたのサイトの開発サーバーが稼働しているときにアクセスできます（通常は http://localhost:8000/___graphql）。</details>

<video controls>
  <source src="https://www.gatsbyjs.org/graphiql-explore.mp4" type="video/mp4">
</video>

<br>

<details><summary>GraphiQLちょっとしたつかいかた</summary>ビルトインの Site "type" をいじくりまわして、どのようなフィールドが利用可能かを確認してください - 先ほど問い合わせた siteMetadata オブジェクトを含む。GraphiQL を開いてデータを弄ってみてください。Ctrl + Space キーを押すとオートコンプリートウィンドウが表示され、Ctrl + Enter キーを押すと GraphQL クエリが実行されます。このチュートリアルの残りの部分では、GraphiQL をもっとたくさん使うことになるでしょう。
</details>

## GraphiQL エクスプローラの使用

<details><summary>メリット</summary>GraphiQL Explorerを使用すると、利用可能なフィールドや入力をクリックしてインタラクティブに完全なクエリを構築することができ、手入力でクエリを入力するという繰り返しのプロセスを必要としません。
</details>

<video controls>
  <source src="https://egghead.io/lessons/gatsby-build-a-graphql-query-using-gatsby-s-graphiql-explorer/embed" type="video/mp4">
</video>

egghead.io でホストされている動画です。

---

## ソース プラグイン

ギャツビーサイト内のデータは、どこからでも入手可能です。API、データベース、CMS、ローカルファイルなどです。

ソースプラグインは、そのソースからデータを取得します。例えば、ファイルシステムのソースプラグインは、ファイルシステムからデータを取得する方法を知っています。WordPress プラグインは WordPress API からデータを取得する方法を知っています。

gatsby-source-filesystem を追加して、それがどのように動作するかを探ってみましょう。

まず、プロジェクトのルートにプラグインをインストールします。

```powershell
npm install --save gatsby-source-filesystem
```

そして、gatsby-config.js に追加します。
gatsby-config.js

````javascript
module.exports = {
  siteMetadata: {
    title: `Pandas Eating Lots`,
  },
  plugins: [
    {
      resolve: `gatsby-source-filesystem`,
      options: {
        name: `src`,
        path: `${__dirname}/src/`,
      },
    },
    `gatsby-plugin-emotion`,
    {
      resolve: `gatsby-plugin-typography`,
      options: {
        pathToConfigModule: `src/utils/typography`,
      },
    },
  ],
}```
````

それを保存して、gatsby 開発サーバーを再起動します。その後、再度 GraphiQL を開きます。

エクスプローラーペインでは、選択項目として allFile とファイルが利用可能になっていることがわかります。

![画像](https://www.gatsbyjs.org/static/88ec3efe94e380d32bc1a20cd82dd8bf/321ea/graphiql-filesystem.png)

allFile ドロップダウンをクリックします。クエリ領域の allFile の後にカーソルを置き、Ctrl + Enter と入力します。これにより、各ファイルの ID に対するクエリが事前に入力されます。Play」を押してクエリを実行します。

![画像](https://www.gatsbyjs.org/static/cf2ffc2f9d3aa512fb742efd377691da/321ea/filesystem-query.png)

エクスプローラ] ペインでは、id フィールドが自動的に選択されています。フィールドに対応するチェックボックスをチェックすることで、より多くのフィールドを選択することができます。再生」を押して、新しいフィールドで再度クエリを実行します。

![画像](https://www.gatsbyjs.org/static/d430ba8bcbc8eb92cd549b70f3798561/321ea/filesystem-explorer-options.png)

または、オートコンプリート ショートカット (Ctrl + Space) を使用してフィールドを追加することもできます。これにより、ファイルノードにクエリ可能なフィールドが表示されます。

![画像](https://www.gatsbyjs.org/static/b2b05958c518b34568861f40449228f4/321ea/filesystem-autocomplete.png)

クエリにいくつかのフィールドを追加してみて、その都度 Ctrl + Enter キーを押してクエリを再実行してください。更新されたクエリ結果が表示されます。

![画像](https://www.gatsbyjs.org/static/077caa982416bc5df87e31f21a1a3417/321ea/allfile-query.png)

結果は、ファイル「ノード」の配列です (ノードは「グラフ」内のオブジェクトの正式名称です)。各ファイルノードオブジェクトには、問い合わせたフィールドがあります。

<br>

---

## GraphQL クエリでページを構築する

Gatsby を使った新しいページの構築は、GraphiQL で始まることが多いです。まずは GraphiQL で遊んでデータクエリをスケッチし、これを React のページコンポーネントにコピーして UI の構築を開始します。

これを試してみましょう。

src/pages/my-files.js に、先ほど作成した allFile GraphQL クエリを含む新しいファイルを作成します。

src/pages/my-files.js

```javascript
import React from "react";
import { graphql } from "gatsby";
import Layout from "../components/layout";

export default function MyFiles({ data }) {
  console.log(data);
  return (
    <Layout>
      <div>Hello world</div>
    </Layout>
  );
}

export const query = graphql`
  query {
    allFile {
      edges {
        node {
          relativePath
          prettySize
          extension
          birthTime(fromNow: true)
        }
      }
    }
  }
`;
```

console.log(data)行は上でハイライトされています。新しいコンポーネントを作成する際に、GraphQL クエリから取得したデータをコンソールに出力しておくと、UI を作成している間にブラウザコンソールでデータを探索することができるので、便利なことがよくあります。

my-files/にある新しいページにアクセスしてブラウザコンソールを開くと、以下のようなものが表示されます。

![画像](https://www.gatsbyjs.org/static/3fd681a2f33d483a82d067b07704f7e5/321ea/data-in-console.png)

データの形状が GraphQL クエリの形状と一致しています。

ファイルデータを印刷するコードをコンポーネントに追加します。

```javascript
import React from "react";
import { graphql } from "gatsby";
import Layout from "../components/layout";

export default function MyFiles({ data }) {
  console.log(data);
  return (
    <Layout>
      <div>
        <h1>My Site's Files</h1>
        <table>
          <thead>
            <tr>
              <th>relativePath</th>
              <th>prettySize</th>
              <th>extension</th>
              <th>birthTime</th>
            </tr>
          </thead>
          <tbody>
            {data.allFile.edges.map(({ node }, index) => (
              <tr key={index}>
                <td>{node.relativePath}</td>
                <td>{node.prettySize}</td>
                <td>{node.extension}</td>
                <td>{node.birthTime}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}

export const query = graphql`
  query {
    allFile {
      edges {
        node {
          relativePath
          prettySize
          extension
          birthTime(fromNow: true)
        }
      }
    }
  }
`;
```

そして今、http://localhost:8000/my-files...😲。

![画像](https://www.gatsbyjs.org/static/d5507ac06a742b5fe3a91a40f9c3148a/321ea/my-files-page.png)

## 次は何が来るの？

これで、ソースプラグインがどのようにしてデータをギャッツビーのデータシステムに持ち込むかを学びました。次のチュートリアルでは、トランスフォーマープラグインがソースプラグインによってもたらされた生のコンテンツをどのように変換するかを学びます。ソースプラグインとトランスフォーマープラグインを組み合わせることで、Gatsby サイトを構築する際に必要になるかもしれないすべてのデータソーシングとデータ変換を処理することができます。トランスフォーマープラグインについては、チュートリアルのパート 6 で学びましょう。

https://www.gatsbyjs.org/tutorial/part-six/
