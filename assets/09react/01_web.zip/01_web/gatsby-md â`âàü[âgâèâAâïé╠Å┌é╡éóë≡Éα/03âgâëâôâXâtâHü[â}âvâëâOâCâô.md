> 参考サイト
> https://www.gatsbyjs.org/tutorial/part-five/

# トランスフォーマプラグイン

<details><summary>このチュートリアルの内容は？</summary>前回のチュートリアルでは、ソースプラグインがどのようにしてGatsbyのデータシステムにデータを持ち込むかを説明しました。このチュートリアルでは、トランスフォーマープラグインがソースプラグインによってもたらされた生のコンテンツをどのように変換するかを学びます。ソースプラグインとトランスフォーマープラグインを組み合わせることで、Gatsbyサイトを構築する際に必要になるかもしれないすべてのデータソーシングとデータ変換を処理することができます。</details>

## トランスフォーマプラグイン

<details><summary>適切なデータに変換できる　例:md→html</summary>多くの場合、ソースプラグインから取得したデータのフォーマットは、あなたのウェブサイトを構築するために使用したいものではありません。ファイルシステムのソースプラグインではファイルに関するデータを問い合わせることができますが、ファイル内のデータを問い合わせたい場合はどうしたらいいでしょうか？

これを可能にするために、Gatsby はトランスフォーマープラグインをサポートしています。

例えば、Markdown ファイルです。マークダウンは書き込めるのはいいですが、それを使ってページを構築する場合、マークダウンは HTML である必要があります。

src/pages/sweet-pandas-eating-sweets.md (これがあなたの最初のマークダウンブログ記事になります) にマークダウンファイルを追加して、変換プラグインと GraphQL を使って HTML に変換する方法を学びましょう。</details>

マークダウンファイルを HTML に変換するために、md ファイルを準備する

src/pages/sweet-pandas-eating-sweets.md

```md
---
title: "Sweet Pandas Eating Sweets"
date: "2017-08-10"
---

Pandas are really sweet.

Here's a video of a panda eating sweets.

<iframe width="560" height="315" src="https://www.youtube.com/embed/4n0xNbfJLR8" frameborder="0" allowfullscreen></iframe>
```

ファイルを保存したら、再度/my-files/を見てみてください-新しいマークダウンファイルは表の中にあります。これは Gatsby の非常に強力な機能です。先ほどの siteMetadata の例のように、ソースプラグインはデータをライブリロードすることができます。 gatsby-source-filesystem は常に新しいファイルが追加されるかどうかをスキャンし、追加されたときには、クエリを再実行します。

マークダウンファイルを変換できるトランスフォーマープラグインを追加します。

```powershell
npm install --save gatsby-transformer-remark
```

そして、 gatsby-config.js に追加します。
gatsby-config.js

```javascript
module.exports = {
  siteMetadata: {
    title: `Pandas Eating Lots`,
  },
  plugins: [
    {
      resolve: `gatsby-source-filesystem`,
      options: {
        name: `src`,
        path: `${__dirname}/src/`,
      },
    },
    `gatsby-transformer-remark`,
    `gatsby-plugin-emotion`,
    {
      resolve: `gatsby-plugin-typography`,
      options: {
        pathToConfigModule: `src/utils/typography`,
      },
    },
  ],
};
```

開発サーバーを再起動してから、GraphiQL をリフレッシュ（または開き直し）して、オートコンプリートを見てください。

![画像](https://www.gatsbyjs.org/static/646695e05a4aafdf903b727c8013f6b7/321ea/markdown-autocomplete.png)

再び allMarkdownRemark を選択し、allFile で行ったように実行します。そこには、最近追加した Markdown ファイルが表示されます。MarkdownRemark ノードで利用可能なフィールドを調べます。

![画像](https://www.gatsbyjs.org/static/646695e05a4aafdf903b727c8013f6b7/321ea/markdown-autocomplete.png)

OK！ うまくいけば、いくつかの基本が定位置に収まり始めていることを願っています。ソースプラグインは Gatsby のデータシステムにデータを持ち込み、トランスフォーマープラグインはソースプラグインが持ってきた生のコンテンツを変換します。このパターンは、Gatsby サイトを構築する際に必要になるかもしれないすべてのデータソーシングとデータ変換を処理することができます。

## src/pages/index.js にサイトのマークダウンファイルのリストを作成します。

さて、あなたはフロントページにあなたのマークダウンファイルのリストを作成する必要があります。多くのブログのように、フロントページに各ブログ記事へのリンクのリストを作成したいと思います。GraphQL を使えば、マークダウンブログ記事の現在のリストを問い合わせることができるので、手動でリストを管理する必要はありません。

src/pages/my-files.js ページと同様に、src/pages/index.js を以下のように置き換えて、初期の HTML とスタイリングで GraphQL クエリを追加します。

src/pages/index.js

```javascript
import React from "react"
import { graphql } from "gatsby"
import { css } from "@emotion/core"
import { rhythm } from "../utils/typography"
import Layout from "../components/layout"

export default function Home({ data }) {
  console.log(data)
  return (
    <Layout>
      <div>
        <h1
          css={css`
            display: inline-block;
            border-bottom: 1px solid;
          `}
        >
          Amazing Pandas Eating Things
        </h1>
        <h4>{data.allMarkdownRemark.totalCount} Posts</h4>
        {data.allMarkdownRemark.edges.map(({ node }) => (
          <div key={node.id}>
            <h3
              css={css`
                margin-bottom: ${rhythm(1 / 4)};
              `}
            >
              {node.frontmatter.title}{" "}
              <span
                css={css`
                  color: #bbb;
                `}
              >
                — {node.frontmatter.date}
              </span>
            </h3>
            <p>{node.excerpt}</p>
          </div>
        ))}
      </div>
    </Layout>
  )
}

export const query = graphql`
  query {
    allMarkdownRemark {
      totalCount
      edges {
        node {
          id
          frontmatter {
            title
            date(formatString: "DD MMMM, YYYY")
          }
          excerpt
        }
      }
    }
  }
```

これでフロントページは以下のようになるはずです。

![画像](https://www.gatsbyjs.org/static/c12c3c281af8226af74349e0f316b797/321ea/frontpage.png)

しかし、あなたのブログ記事は 1 つだけだと少し寂しい感じがします。そこで、src/pages/pandas-and-bananas.md に別の記事を追加してみましょう。

src/pages/pandas-and-bananas.md

```md
---
title: "Pandas and Bananas"
date: "2017-08-21"
---

Do Pandas eat bananas? Check out this short video that shows that yes! pandas do seem to really enjoy bananas!

<iframe width="560" height="315" src="https://www.youtube.com/embed/4SZl1r2O_bY" frameborder="0" allowfullscreen></iframe>
```

![画像](https://www.gatsbyjs.org/static/d7b4537b69b87253593231268802baaa/321ea/two-posts.png)

これはいいね！ただ...投稿の順番が間違っています。

しかし、これは簡単に直せます。何らかのタイプの接続を問い合わせる際には、GraphQL クエリに様々な引数を渡すことができます。ノードのソートやフィルタリング、スキップするノード数の設定、取得するノード数の上限の設定などができます。この強力な演算子のセットを使用すると、必要な形式で任意のデータを選択することができます。

インデックスページの GraphQL クエリで、`allMarkdownRemark` を`allMarkdownRemark(sort: { fields: [frontmatter___date], order: DESC })`に変更します。注: frontmatter と date の間には 3 つのアンダースコアがあります。これを保存すれば、ソート順は修正されるはずです。

GraphiQL を開いて、さまざまなソートオプションを試してみてください。allFile 接続を他の接続と一緒にソートすることができます。

クエリ演算子の詳細については、GraphQL リファレンスガイドを参照してください。

## 挑戦

ブログ記事を含むページを新たに作ってみて、ホームページのブログ記事一覧がどうなるか見てみましょう

# 次は何が来るの？

これは素晴らしいですね! あなたはマークダウンファイルをクエリして、ブログ記事のタイトルと抜粋のリストを作成する素敵なインデックスページを作成しました。しかし、単に抜粋を見たいのではなく、マークダウンファイルのための実際のページが必要です。

src/pages に React コンポーネントを配置することでページを作成し続けることができます。しかし、次にデータからプログラム的にページを作成する方法を学びます。Gatsby は、多くの静的サイトジェネレータのようにファイルからページを作成することに限定されていません。Gatsby では、GraphQL を使ってデータをクエリし、クエリ結果をページにマッピングすることができます。これは本当に強力なアイデアです。次のチュートリアルでは、データからプログラムでページを作成する方法を学びます。

https://www.gatsbyjs.org/tutorial/part-seven/
