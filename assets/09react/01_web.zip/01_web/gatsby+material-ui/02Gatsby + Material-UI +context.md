# Gatsby + Material-UI ダークモード実装方法(context あり)

目標
左上のボタンで、ダークモードと、ライトモードを変更できるようにする
![画像](001.png)

手順のみ

https://github.com/mui-org/material-ui/tree/master/examples/gatsby
にてダウンロードする。

`/gatsby`で`npm install`を実行し、npm をインストール

以下のコマンドで、Gatsby をテスト起動する。

```shell
gatsby develop
```

確認サイト
http://localhost:8000/

サイトが立ち上がれば OK

![画像](002.png)
もちろん、まだこの状態では、ボタンで、ダークモードに変更することはできない。

<br>
<br>

---

# ダークモード切り替えを実装する

各ページのコンポーネントツリー最上位に位置する plugins/gatsby-plugin-top-layout/TopLayout.js にリデューサ を導入し、その dispatch 関数をコンテクストとして下層のコンポーネントに受け渡す。

コンテクストを使ったカスタムフックを作成し他のコンポーネント内から呼び出す。

編集するのは以下の 4 ファイルです。

1. **作成**: src/themeReducer.js

2. **作成**: src/DispatchContext.js

3. 変更: plugins/gatsby-plugin-top-layout/TopLayout.js

4. **作成**: src/components/DarkModeButton.js

<br>

# 1. 作成: src/themeReducer.js

/src/themeReducer.js

```js
/** TypeScript を使う場合
 *
 *  export interface ThemeState {
 *    darkMode: boolean;
 *  }
 *  export type Action = { type: 'TOGGLE_DARKMODE' };
 */

// 初期ステートを定義
export const initialState = {
  darkMode: false,
};

// リデューサの定義
export const themeReducer = (state, action) => {
  switch (action.type) {
    case "TOGGLE_DARKMODE":
      return {
        ...state,
        darkMode: !state.darkMode,
      };
    default:
      throw new Error();
  }
};
```

# 2. 作成: src/DispatchContext.js

コンテクストとカスタムフックの作成をおこないます。
/src/DispatchContext.js

```js
import React from "react";

/** TypeScript を使う場合
 *
 *  import { Action } from './themeReducer';
 *
 *  const DispatchContext =
 *  React.createContext<React.Dispatch<Action>>(...)
 */

// コンテクストの作成
export const DispatchContext = React.createContext(() => {
  throw new Error();
});

// カスタムフックの作成
export function useToggleDarkMode() {
  const dispatch = React.useContext(DispatchContext);
  return React.useCallback(() => dispatch({ type: "TOGGLE_DARKMODE" }), [
    dispatch,
  ]);
}
```

コンテクスト について
[React コンテクスト](https://ja.reactjs.org/docs/hooks-reference.html#usecontext)

# 3. 変更: plugins/gatsby-plugin-top-layout/TopLayout.js

作成したリデューサとコンテクストを <TopLayout> コンポーネント内で使用します。

/plugins/gatsby-plugin-top-layout/TopLayout.js

```js
import React from "react";
import PropTypes from "prop-types";
import { Helmet } from "react-helmet";
import CssBaseline from "@material-ui/core/CssBaseline";
import { ThemeProvider, createMuiTheme } from "@material-ui/core/styles";

import initialTheme from "../../src/theme";
import { themeReducer, initialState } from "../../src/themeReducer";
import { DispatchContext } from "../../src/DispatchContext";

export default function TopLayout(props) {
  // React.useReducer でリデューサの導入
  const [state, dispatch] = React.useReducer(themeReducer, initialState);
  const { darkMode } = state;
  // React.useMemo でステートに応じた theme を作成
  const theme = React.useMemo(() => {
    return createMuiTheme({
      ...initialTheme,
      palette: {
        type: darkMode ? "dark" : "light",
        primary: initialTheme.palette.primary,
        secondary: initialTheme.palette.secondary,
      },
    });
  }, [darkMode]);

  return (
    <React.Fragment>
      <Helmet>
        <meta
          name="viewport"
          content="minimum-scale=1, initial-scale=1, width=device-width"
        />
        <link
          href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&display=swap"
          rel="stylesheet"
        />
      </Helmet>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        {/* DispatchContext.Provider を挿入 */}
        <DispatchContext.Provider value={dispatch}>
          {props.children}
        </DispatchContext.Provider>
      </ThemeProvider>
    </React.Fragment>
  );
}

TopLayout.propTypes = {
  children: PropTypes.node,
};
```

- [`React.useReducer`][リデューサ] を使って `<TopLayout>` にステートを作成
- [`React.useMemo`](https://ja.reactjs.org/docs/hooks-reference.html#usememo) を使ってステートに応じた `MuiTheme` を再生産
- `<ThemeProvider>` の子要素にプロバイダコンポーネントである [`<DispatchContext.Provider>`](https://ja.reactjs.org/docs/context.html#contextprovider) を挿入
- `<DispatchContext.Provider>` の値に `dispatch` 関数を設定

`dispatch` はコンテクストとして、子要素に渡されます。子要素からステートが変更された時に、`<TopLayout>` 内で `MuiTheme` を再生産し、ページ全体のデザインを更新します。
これでダークモードの実装、コンポーネントツリー下層から最上層の `MuiTheme` の更新という裏テーマを達成しました。

先ほど作成したカスタムフック useToggleDarkMode でパレットタイプ切り替えのアイコンボタンを作ってみましょう。

# 4. 作成: src/components/DarkModeButton.js

@material-ui/icons をインストールします。

`npm add @material-ui/icons`

/src/components/DarkModeButton.js

```js
import React from "react";
import IconButton from "@material-ui/core/IconButton";
import useTheme from "@material-ui/core/styles/useTheme";
import Brightness4 from "@material-ui/icons/Brightness4";
import Brightness5 from "@material-ui/icons/Brightness5";
import { themeReducer } from "../themeReducer";

function DarkModeButton(props) {
  // パレットタイプを取得
  const paletteType = useTheme().palette.type;
  // パレットタイプ切り替えのフックを使用
  const _toggleDarkMode = themeReducer();

  return (
    <IconButton onClick={_toggleDarkMode} {...props}>
      {paletteType === "dark" ? <Brightness5 /> : <Brightness4 />}
    </IconButton>
  );
}

export default DarkModeButton;
```

Material-UI の `MuiTheme` もコンテクストです。`useTheme` というカスタムフックでどのコンポーネントからでも `MuiTheme` を取得できます。現在のパレットタイプ取得には `useTheme` フックを使います。
ここで定義した `_toggleDarkMode` という変数は、パレットタイプ切り替えを実行するコールバック関数です。

簡潔なコードで書かれたこの `<DarkModeButton>` を好きな場所に置くだけでダークモードの切り替えが可能になります。
[デモページ](https://cieloazul310.github.io/gatsby-material-ui-darkmode/)では作成したレイアウトコンポーネントの中に `<DarkModeButton>` を設置しています。

\src\pages\index.js

```js
import React from "react";
import Container from "@material-ui/core/Container";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import ProTip from "../components/ProTip";
import Link from "../components/Link";
import Copyright from "../components/Copyright";

//追加1
import DarkModeButton from "../components/DarkModeButton.js";

export default function Index() {
  return (
    <Container maxWidth="sm">
      {/* 追加2 */}
      <DarkModeButton />
      <Box my={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          Gatsby v4-beta example
        </Typography>
        <Link to="/about" color="secondary">
          Go to the about page
        </Link>
        <ProTip />
        <Copyright />
      </Box>
    </Container>
  );
}
```

<br>

確認サイト http://localhost:8000/

<br>

# まとめ

ダークモード実装のため、コンポーネントツリー最上位に位置する `TopLayout.js` に[リデューサ](reducer) を導入し、その `dispatch` 関数を[コンテクスト]として下層のコンポーネントに受け渡すことで `MuiTheme` を下層から更新できるようにしました。また、コンテクストを利用した[カスタムフック]を作成することで、他のどのコンポーネント内からでもパレットタイプの切り替えが可能になりました。

props で受け渡すのではなくコンテクストとフックを使った実装なので、既存プロジェクトでも小さい改修コストで導入できます。

今まであまり使っていなかった[コンテクスト]や[カスタムフック]に対する知見が得られてとても勉強になりました。
