# Gatsby starter + Material-UI の導入

参考サイト  
http://yucatio.hatenablog.com/entry/2018/09/23/222857

## やること

- gatsby-starter-default のダウンロード
- ソースプラグインの設定
- トランスフォーマープラグインの設定
- プログラムでデータからページを作成する

<br>

# 環境構築

```shell
# gatsby デフォルトスターター ダウンロード
gatsby new gatsby-starter-default https://github.com/gatsbyjs/gatsby-starter-default
# フォルダ移動
cd gatsby-starter-default
# gatsby 起動
gatsby develop

```

Gatsby サーバが起動している事を確認する

確認ページ  
http://localhost:8000/

<br>

# Material-UI の導入

material-ui を導入

```shell
npm install gatsby-plugin-material-ui @material-ui/styles
npm install @material-ui/core @material-ui/icons
```

以下より Material-UI を使いやすくするプラグイン をダウンロードする

https://github.com/mui-org/material-ui/tree/master

![画像](003.png)

ダウンロードしたファイルから
`material-ui-next\examples\gatsby\src\theme.js`を`src\`にコピー

`material-ui-next\examples\gatsby\plugins`を`gatsby-starter-default\`にコピー

`gatsby-config.js`に以下を追加(plugins に追記)

gatsby-config.js

```js
module.exports = {
  plugins: [
    //追加
    "gatsby-plugin-top-layout",
    {
      resolve: "gatsby-plugin-material-ui",
      options: {},
    },
    //ここまで
  ],
};
```

# Material-UI を試す

## ボタンを追加してみよう

参考ページ
https://material-ui.com/getting-started/usage/

`src\pages\index.js`

```jsx
//追加
import Button from "@material-ui/core/Button";

//  <Layout>内の適当な場所に追加
<Button variant="contained" color="primary">
  Hello World
</Button>;
```

確認ページ
http://localhost:8000/

![画像](004.png)

# Material-UI の theme を変更

`src/theme.js`

```js
import { red } from "@material-ui/core/colors";
import { createMuiTheme } from "@material-ui/core/styles" "@material-ui/icons/Menu";

// A custom theme for this app
const theme = createMuiTheme({
  palette: {
    primary: {
      light: "#ffffff",
      main: "#f9f9f9",
      dark: "#c6c6c6",
      contrastText: "#3e2723",
    },
    secondary: {
      light: "#fffffb",
      main: "#d7ccc8",
      dark: "#a69b97",
      contrastText: "#37474f",
    },
    error: {
      main: red.A400,
    },
    background: {
      default: "#fff",
    },
  },
});

export default theme;
```

- createMuiTheme にテーマカラーを渡すことでデフォルトの設定を上書きできる

作成したテーマをコンポーネントに渡します。<App>を<MuiThemeProvider>で囲うことでカスタマイズしたテーマを使用することができます。

例:
`index.js`

```js
import { MuiThemeProvider } from "@material-ui/core/styles"; // 追加
import { theme } from "./materialui/theme"; // 追加

// 略

render(
  <Provider store={store}>
    <MuiThemeProvider theme={theme}>
      {" "}
      {/* 追加 */}
      <App />
    </MuiThemeProvider>{" "}
    {/* 追加 */}
  </Provider>,
  document.getElementById("root")
);
```
