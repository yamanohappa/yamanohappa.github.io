# Redux チュートリアル Usage with React

[Read Me | Redux チュートリアル Usage with React
](https://redux.js.org/basics/usage-with-react)

- [<font color=#FF1493>Action</font>](01Action.md)
- [<font color=#4682B4> Reducers</font>](02Reducers.md)
- [<font color=#FF8C00>Store</font>](03Store.md)← は単一で、中に state が複数
- [Data Flow](04DataFlow.md)
- [Usage with React](05UsagewithReact.md)

---

## Redux の構成

Redux と React を利用したサンプルアプリケーションの構成  
![構成画像](2016-redux-react.png)  
Redux + React の構成イメージ

<br>
<br>

---

## Usage with React

Redux は React とは無関係であることを強調しておく必要があります。React、Angular、Ember、jQuery、バニラ JavaScript で Redux アプリを書くことができます。

とはいえ、React や Deku のようなライブラリと Redux は特に相性が良く、UI を状態の関数として記述でき、Redux はアクションに応じて状態を更新します。

ここでは React を使ってシンプルな todo アプリを構築し、React と Redux の使い方の基本を説明します。

> 注：Redux と React を一緒に使用する方法の完全なガイドについては、https://react-redux.js.org にある React-Redux の公式ドキュメントを参照してください。

<br>
<br>

---

### React Redux のインストール

React バインディングはデフォルトでは Redux に含まれていません。明示的にインストールする必要があります。

```powershell
npm install react-redux
```

<br>
<br>

---

### プレゼンテーションとコンテナの構成要素

Redux 用の React バインディングは、プレゼンテーションコンポーネントとコンテナコンポーネントを分離します。このアプローチにより、アプリがより分かりやすくなり、コンポーネントをより簡単に再利用できるようになります。以下に、プレゼンテーションコンポーネントとコンテナコンポーネントの違いをまとめました（ただし、よくわからない場合は、プレゼンテーションコンポーネントとコンテナコンポーネントの概念について説明している Dan Abramov 氏の元記事も併せて読むことをお勧めします）。

|                      | Presentational(プレゼン) Components | Container(コンテナ) Components         |
| -------------------- | ----------------------------------- | -------------------------------------- |
| 目的                 | 外観（マークアップ、スタイル）      | 仕組み（データの取得、状態の更新）     |
| Redux の認識         | ×                                   | ○                                      |
| データを読み取るには | props からデータを読み取る          | Redux subscribe()で状態を得る          |
| データを変更するには | props からコールバックを呼び出す    | Redux アクションのディスパッチ         |
| 書かれている         | 手動                                | 通常、React Redux によって生成されます |

これから書くコンポーネントのほとんどはプレゼンテーション用のものですが、Redux <font color=#FF8C00>Store</font>に接続するためにいくつかのコンテナコンポーネントを生成する必要があります。これと以下の設計概要は、コンテナコンポーネントがコンポーネントツリーの一番上になければならないということを意味するものではありません。もしコンテナコンポーネントが複雑になりすぎた場合（つまり、無数のコールバックが渡されているような、ネストしたように重く入れ子になったプレゼンテーションコンポーネントを持っている場合）、FAQ にあるように、コンポーネントツリーの中に別のコンテナを導入してください。

技術的には <font color=#009900>store.subscribe()</font> を使ってコンテナコンポーネントを手書きで書くことができます。しかし、React Redux は多くのパフォーマンスの最適化を行っており、手作業では難しいため、これを行うことはお勧めしません。このため、コンテナコンポーネントを書くのではなく、React Redux が提供する <font color=#009900>connect()</font> 関数を使って、以下のようにコンテナコンポーネントを生成します。

<br>
<br>

---

### コンポーネント階層の設計

ルートステートオブジェクトの形状をどのようにデザインしたか覚えていますか？そろそろそれに合わせて UI 階層を設計しましょう。これは Redux 特有の作業ではありません。Thinking in React はプロセスを説明した素晴らしいチュートリアルです。

私たちのデザインの概要はシンプルです。TODO アイテムのリストを表示したいのです。クリックすると、Todo 項目が完了したと表示されます。ユーザーが新しい ToDo を追加できるフィールドを表示したい。フッターには、すべての ToDo、完了した ToDo のみ、またはアクティブな ToDo のみを表示するトグルを表示したいと思います。

#### プレゼン用のコンポーネントをデザインする

私は、この短信から次のようなプレゼンテーションの構成要素とその小道具が浮かび上がってくるのを見ています。

- **TodoList** 表示される ToDo を示すリストです。
  - **todos: Array{ id, text, completed }**  
    形状のある ToDo 項目の配列です。
  - **onTodoClick(id: number)**  
    todo がクリックされたときに呼び出すコールバックです。
- **Todo** 単一の ToDo アイテムです。
  - **text: string** 表示するテキストです。
  - **completed: boolean** todo を取り消し線で表示するかどうかです。
  - **onClick() todo** がクリックされたときに呼び出すコールバックです。
- **Link** コールバック付きのリンクです。
  - **onClick()** リンクがクリックされたときに呼び出すコールバックです。
- **Footer** ユーザーに現在表示されているタスクを変更させる場所です。
- **App** 他のすべてをレンダリングするルートコンポーネントです。

それらは見た目を説明しますが、データがどこから来ているのか、どうやって変更するのかを知りません。彼らは与えられたものをレンダリングするだけです。Redux から他のものに移行しても、これらのコンポーネントはすべてまったく同じに保つことができます。これらのコンポーネントは Redux に依存しません。

#### コンテナコンポーネントの設計

また、プレゼンテーション用コンポーネントを Redux に接続するために、いくつかのコンテナコンポーネントも必要になります。例えば、プレゼンテーション用の TodoList コンポーネントには、Redux ストアにサブスクライブし、現在の可視性フィルタを適用する方法を知っている VisibleTodoList のようなコンテナが必要です。可視性フィルターを変更するには、クリック時に適切なアクションをディスパッチするリンクをレンダリングする FilterLink コンテナコンポーネントを提供します。

- VisibleTodoList は、現在の可視性フィルタに従って TODO をフィルタリングし、TodoList を表示します。
- FilterLink は、現在の可視性フィルタを取得し、リンクを表示します。
  - filter: 文字列は、それが表す可視性フィルタです。

#### その他のコンポーネントの設計

時には、あるコンポーネントが現在のコンポーネントであるべきなのか、コンテナであるべきなのかを見分けるのが難しいことがあります。例えば、この小さなコンポーネントの場合のように、フォームと関数が本当に一緒になっていることがあります。

- AddTodo は「追加」ボタンのある入力フィールドです。
  技術的には 2 つのコンポーネントに分けることもできますが、現段階では早すぎるかもしれません。プレゼンとロジックが混在していても良いのですが、非常に小さなコンポーネントです。成長するにつれ、どうやって分割すればいいのかが明確になってくると思うので、混ぜたままにしておきます。

### コンポーネントの実装

コンポーネントを書こう Redux へのバインディングを考える必要はありません。

#### プレゼンテーションコンポーネントの実装

これらはすべて通常の React コンポーネントなので、詳しくは調べません。ローカルステートやライフサイクルメソッドを使用する必要がない限り、機能的なステートレスコンポーネントを書きます。この方法で定義した方が簡単なだけです。ローカル状態やライフサイクル・メソッド、パフォーマンスの最適化などを追加する必要がある場合は、それらをクラスに変換することができます。
components/Todo.js

```javascript
import React from "react";
import PropTypes from "prop-types";

const Todo = ({ onClick, completed, text }) => (
  <li
    onClick={onClick}
    style={{
      textDecoration: completed ? "line-through" : "none",
    }}
  >
    {text}
  </li>
);

Todo.propTypes = {
  onClick: PropTypes.func.isRequired,
  completed: PropTypes.bool.isRequired,
  text: PropTypes.string.isRequired,
};

export default Todo;
```

components/TodoList.js

```javascript
import React from "react";
import PropTypes from "prop-types";
import Todo from "./Todo";

const TodoList = ({ todos, onTodoClick }) => (
  <ul>
    {todos.map((todo, index) => (
      <Todo key={todo.id} {...todo} onClick={() => onTodoClick(todo.id)} />
    ))}
  </ul>
);

TodoList.propTypes = {
  todos: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      completed: PropTypes.bool.isRequired,
      text: PropTypes.string.isRequired,
    }).isRequired
  ).isRequired,
  onTodoClick: PropTypes.func.isRequired,
};

export default TodoList;
```

components/Link.js

```javascript
import React from "react";
import PropTypes from "prop-types";

const Link = ({ active, children, onClick }) => (
  <button
    onClick={onClick}
    disabled={active}
    style={{
      marginLeft: "4px",
    }}
  >
    {children}
  </button>
);

Link.propTypes = {
  active: PropTypes.bool.isRequired,
  children: PropTypes.node.isRequired,
  onClick: PropTypes.func.isRequired,
};

export default Link;
```

components/Footer.js

```powershell
import React from 'react'
import FilterLink from '../containers/FilterLink'
import { VisibilityFilters } from '../actions'

const Footer = () => (
  <p>
    Show: <FilterLink filter={VisibilityFilters.SHOW_ALL}>All</FilterLink>
    {', '}
    <FilterLink filter={VisibilityFilters.SHOW_ACTIVE}>Active</FilterLink>
    {', '}
    <FilterLink filter={VisibilityFilters.SHOW_COMPLETED}>Completed</FilterLink>
  </p>
)

export default Footer
```

#### コンテナコンポーネントの実装

それでは、コンテナを作成して、これらのプレゼンテーションコンポーネントを Redux に接続してみましょう。技術的には、コンテナコンポーネントとは、store.subscribe()を使って Redux のステートツリーの一部を読み込んで、レンダリングするプレゼンテーションコンポーネントにプロップを供給する React コンポーネントのことです。コンテナコンポーネントを手書きで書くこともできますが、代わりに React Redux ライブラリの connect() 関数を使ってコンテナコンポーネントを生成することをお勧めします。この関数は、不必要な再レンダリングを防ぐための多くの便利な最適化を提供します(この結果の 1 つは、React パフォーマンスの推奨事項である shouldComponentUpdate を自分で実装することを心配する必要がないことです)。

connect() を使用するには、現在の Redux ストアの状態を、ラップしているプレゼンテーションコンポーネントに渡したいプロップに変換する方法を記述した mapStateToProps と呼ばれる特別な関数を定義する必要があります。例えば、VisibleTodoList は TodoList に渡す TODOS を計算する必要があるので、state.visibilityFilter に従って state.todos をフィルタリングする関数を定義し、その mapStateToProps で使用します。

```powershell
const getVisibleTodos = (todos, filter) => {
  switch (filter) {
    case 'SHOW_COMPLETED':
      return todos.filter(t => t.completed)
    case 'SHOW_ACTIVE':
      return todos.filter(t => !t.completed)
    case 'SHOW_ALL':
    default:
      return todos
  }
}

const mapStateToProps = state => {
  return {
    todos: getVisibleTodos(state.todos, state.visibilityFilter)
  }
}
```

状態の読み込みに加えて、コンテナコンポーネントはアクションをディスパッチすることができます。同様の方法で、mapDispatchToProps() と呼ばれる関数を定義すると、 dispatch() メソッドを受け取り、プレゼンテーション コンポーネントに注入したいコールバック プロップを返すことができます。たとえば、VisibleTodoList が onTodoClick というプロップを TodoList コンポーネントに注入し、onTodoClick が TOGGLE_TODO アクションをディスパッチするようにしたいとします。

```powershell
const mapDispatchToProps = dispatch => {
  return {
    onTodoClick: id => {
      dispatch(toggleTodo(id))
    }
  }
}
```

最後に、connect()を呼び出して VisibleTodoList を作成し、これら 2 つの関数を渡します。

```powershell
import { connect } from 'react-redux'

const VisibleTodoList = connect(mapStateToProps, mapDispatchToProps)(TodoList)

export default VisibleTodoList
```

これらは React Redux API の基本ですが、いくつかのショートカットやパワーオプションがあるので、そのドキュメントを詳しくチェックすることをお勧めします。mapStateToProps が頻繁に新しいオブジェクトを作成することを心配している場合は、reselect を使った派生データの計算について学ぶとよいでしょう。

以下に定義されている残りのコンテナコンポーネントを見つけてください。
containers/FilterLink.js

```powershell
import { connect } from 'react-redux'
import { setVisibilityFilter } from '../actions'
import Link from '../components/Link'

const mapStateToProps = (state, ownProps) => {
  return {
    active: ownProps.filter === state.visibilityFilter
  }
}

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    onClick: () => {
      dispatch(setVisibilityFilter(ownProps.filter))
    }
  }
}

const FilterLink = connect(mapStateToProps, mapDispatchToProps)(Link)

export default FilterLink
```

containers/VisibleTodoList.js

```powershell
import { connect } from 'react-redux'
import { toggleTodo } from '../actions'
import TodoList from '../components/TodoList'

const getVisibleTodos = (todos, filter) => {
  switch (filter) {
    case 'SHOW_ALL':
      return todos
    case 'SHOW_COMPLETED':
      return todos.filter(t => t.completed)
    case 'SHOW_ACTIVE':
      return todos.filter(t => !t.completed)
  }
}

const mapStateToProps = state => {
  return {
    todos: getVisibleTodos(state.todos, state.visibilityFilter)
  }
}

const mapDispatchToProps = dispatch => {
  return {
    onTodoClick: id => {
      dispatch(toggleTodo(id))
    }
  }
}

const VisibleTodoList = connect(mapStateToProps, mapDispatchToProps)(TodoList)

export default VisibleTodoList
```
