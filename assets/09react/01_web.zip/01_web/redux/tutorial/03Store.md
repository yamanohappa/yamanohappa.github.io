# Redux チュートリアル <font color=#FF8C00>Store</font>

[Read Me | Redux チュートリアル Store](https://redux.js.org/basics/store)

- [<font color=#FF1493>Action</font>](01Action.md)
- [<font color=#4682B4> Reducers</font>](02Reducers.md)
- [<font color=#FF8C00>Store</font>](03Store.md)← は単一で、中に state が複数
- [Data Flow](04DataFlow.md)
- [Usage with React](05UsagewithReact.md)

---

## Redux の構成

Redux と React を利用したサンプルアプリケーションの構成  
![構成画像](2016-redux-react.png)  
Redux + React の構成イメージ

<br>
<br>

---

## <font color=#FF8C00>Store</font>

前節では、「何が起こったか」に関する事実を表す<font color=#FF1493>Action</font>と、その<font color=#FF1493>Action</font>に応じて状態(state)を更新する<font color=#4682B4> Reducers</font>
を定義しました。

ストアは、これらをまとめるオブジェクトです。ストアには以下のような役割があります。

- アプリケーションの状態を保持します。
- <font color=#009900> getState()</font>
  で状態にアクセスできるようにします。
- <font color=#009900> dispatch(action) </font> で状態を更新できるようにします。
- <font color=#009900>subscribe(listener) </font> でリスナーを登録します。
- <font color=#009900>subscribe(listener) </font> が返す関数を介してリスナーの登録を解除します。

ここで注意したいのは、Redux アプリケーションでは 1 つの<font color=#FF8C00>Store</font>しか持たないということです。データ処理ロジックを分割したい場合は、多数のストアではなく、<font color=#4682B4> Reducers</font>構成を使用します。

<font color=#4682B4> Reducers</font>があれば<font color=#FF8C00>Store</font>を作るのは簡単です。前のセクションでは、<font color=#009900>combineReducers()</font>を使って複数のレデューサを 1 つにまとめました。今度はそれをインポートして <font color=#009900>createStore()</font>に渡します。

```javascript
import { createStore } from "redux";
import todoApp from "./reducers";
const store = createStore(todoApp);
```

オプションで、<font color=#009900>createStore()</font> の第二引数に初期状態を指定することができます。これは、サーバ上で動作している Redux アプリケーションの状態に合わせてクライアントの状態を調整するのに便利です。

```javascript
const store = createStore(todoApp, window.STATE_FROM_SERVER);
```

<br>
<br>

---

## Dispatching Actions

<font color=#FF8C00>Store の関数</font>を作成したので、プログラムが動作することを確認してみましょう UI がなくても、更新ロジックをテストすることができます。

```javascript
import {
  addTodo,
  toggleTodo,
  setVisibilityFilter,
  VisibilityFilters,
} from "./actions";

// Log the initial state
console.log(store.getState());

// Every time the state changes, log it
// Note that subscribe() returns a function for unregistering the listener
const unsubscribe = store.subscribe(() => console.log(store.getState()));

// Dispatch some actions
store.dispatch(addTodo("Learn about actions"));
store.dispatch(addTodo("Learn about reducers"));
store.dispatch(addTodo("Learn about store"));
store.dispatch(toggleTodo(0));
store.dispatch(toggleTodo(1));
store.dispatch(setVisibilityFilter(VisibilityFilters.SHOW_COMPLETED));

// Stop listening to state updates
unsubscribe();
```

これで、<font color=#FF8C00>Store の関数</font>が保持している状態(state)が変化してしまうことがわかります。

UI を書き始める前にアプリの動作を指定しました。このチュートリアルではこれを行いませんが、この時点で<font color=#4682B4> Reducers</font>や<font color=#FF1493>Action Creator</font>のテストを書くことができます。これらは純粋な関数なので、何もモックする必要はありません。これらを呼び出して、何を返すかをアサーションしてください。
<br>
<br>

---

## ソースコード

index.js

```javascript
import { createStore } from "redux";
import todoApp from "./reducers";

const store = createStore(todoApp);
```

<br>
<br>

---

todo アプリの UI を作成する前に、Redux アプリでデータがどのように流れるのか、寄り道しながら見ていきます。

[次へ Data Flow](04DataFlow.md)

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

---

## <font color=#FF8C00>Store の関数</font>

### **getState()**

アプリケーションの現在の状態ツリーを返します。これは、ストアのレデューサによって返された最後の値に等しくなります。

#### 戻り値

アプリケーションの現在の状態ツリー

### **dispatch(action)**

アクションをディスパッチ(送信)します。状態変化をトリガーする唯一の方法です。

ストアのリダクション関数は、現在の<font color=#009900> getState()</font> の結果と与えられたアクションが同期的に呼び出されます。その戻り値は次の状態とみなされます。今後は<font color=#009900> getState()</font> から返され、変更リスナーには直ちに通知されます。

#### 戻り値

（オブジェクト）：ディスパッチされたアクション

例

```javascript
import { createStore } from "redux";
const store = createStore(todos, ["Use Redux"]);

function addTodo(text) {
  return {
    type: "ADD_TODO",
    text,
  };
}

//↓storeのdispatch()
store.dispatch(addTodo("Read the docs"));
store.dispatch(addTodo("Read about the middleware"));
```

### **subscribe(listener)**

変更リスナーを追加します。これは、<font color=#FF1493>Action</font>がディスパッチされ、ステートツリーの一部が変更された可能性がある場合に呼び出されます。そして <font color=#009900> getState()</font> をコールバック内で呼び出して、現在のステートツリーを読み取ることができます。

変更リスナーから <font color=#009900> dispatch()</font> を呼び出すことができますが、以下の注意点があります。

1. リスナーが dispatch() をコールすべきなのは、ユーザのアクションへの応答か、特定の条件 (例えば、ストアが特定のフィールドを持っているときにアクションをディスパッチするなど) のいずれかに限られます。条件を指定せずに dispatch() を呼び出すことは技術的には可能ですが、 dispatch() を呼び出すたびにリスナーが再び呼び出されてしまうため、無限ループになってしまいます。
2. サブスクリプションは、すべての dispatch() コールの直前にスナップショットされます。リスナーが呼び出されている間にサブスクライブやアンスクライブを行っても、現在進行中の dispatch() には何の影響もありません。しかし、ネストされているかどうかに関わらず、次の dispatch() コールでは、サブスクリプションリストのより最近のスナップショットが使用されます。

3. リスナーは、リスナーが呼ばれる前に入れ子になった dispatch() の間にステートが複数回更新されているかもしれないので、すべてのステートの変更を見ることを期待してはいけない。しかし、 dispatch() が開始される前に登録されたすべてのサブスクライバが、 dispatch() が終了するまでに最新の状態で呼び出されることは保証されています。

これは低レベルの API です。ほとんどの場合、これを直接使うのではなく、React (または他の) バインディングを使うことになるでしょう。コールバックを状態変化に反応するためのフックとしてよく使う場合は、カスタムの observeStore ユーティリティを書いた方がいいかもしれません。ストアは Observable でもあるので、RxJS のようなライブラリを使って変更をサブスクライブすることができます。

変更リスナーのサブスクライブを解除するには、subscribe で返された関数を呼び出します。

例

```javascript
function select(state) {
  return state.some.deep.property;
}

let currentValue;
function handleChange() {
  let previousValue = currentValue;
  currentValue = select(store.getState());

  if (previousValue !== currentValue) {
    console.log(
      "Some deep nested property changed from",
      previousValue,
      "to",
      currentValue
    );
  }
}

const unsubscribe = store.subscribe(handleChange);
unsubscribe();
```

### **replaceReducer(nextReducer)**

現在<font color=#FF8C00>Store</font>が状態を計算するために使用している<font color=#4682B4> Reducers</font>を置き換えます。

これは高度な API です。アプリがコード分割を実装していて、いくつかの<font color=#4682B4> Reducers</font>を動的にロードしたい場合に必要になるかもしれません。また、Redux のホットリロード機構を実装する場合にも必要になるかもしれません。

[次へ Data Flow](04DataFlow.md)
