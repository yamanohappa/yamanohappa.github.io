# Redux チュートリアル <font color=#FF1493>Action</font>

[Read Me | Redux チュートリアル Action](https://redux.js.org/basics/actions)

- [<font color=#FF1493>Action</font>](01Action.md)
- [<font color=#4682B4> Reducers</font>](02Reducers.md)
- [<font color=#FF8C00>Store</font>](03Store.md)← は単一で、中に state が複数
- [Data Flow](04DataFlow.md)
- [Usage with React](05UsagewithReact.md)

---

## Redux の構成

Redux と React を利用したサンプルアプリケーションの構成
![構成画像](2016-redux-react.png)
Redux + React の構成イメージ

<br>
<br>

---

## <font color=#FF1493>Action</font>

Action はアプリケーションから Store のデータを送信する情報のペイロード(情報の本体[ヘッダなどを含まない])です

<font color=#009900>store.dispatch()</font> を使用することで、Store に送信できます

ToDo アプリに、やることの追加を表す Action の例を次に示します

```javascript
const ADD_TODO = "ADD_TODO";
```

```javascript
{
  type: ADD_TODO,
  text: '○○を行う(todoの内容)'
}
```

Action はただの JavaScript オブジェクトで、実行される Action のタイプを示す type プロパティを持つ必要がある。

type は通常、文字列定数として定義する必要があります。アプリが十分に大きくなったら、これらを別のモジュールに移動することができます。

以下 type を別ファイルに定義する場合

```javascript
import { ADD_TODO, REMOVE_TODO } from "../actionTypes";
```

type 以外の Action 要素の構造は、自由です。  
もっと →Flux Standard Action を参照して、アクションの構築方法。

次に ToDo リストの完了を表す Action を追加します。

```javascript
{
  type: TOGGLE_TODO,
  index: 5
}
```

<br>  
最後に、現在表示されているToDoを変更するためのActionのtypeを追加します。

```javascript
{
  type: SET_VISIBILITY_FILTER,
  filter: SHOW_COMPLETED
  //今回は完了しているリストのみ表示など
}
```

<br>
<br>

---

## <font color=#FF1493>Action Creators</font>

Action Creator は Action を作成するやつ

**Redux では、Action Creator は単に Action を返すだけッス。**  
Action Creator 関数を実行すると、対応した Action の中身が返ってくるだけ

```javascript
function addTodo(text) {
  return {
    type: ADD_TODO,
    text,
  };
}
```

そのため、単体でのテストが楽です

ディスパッチ(アクションを Reducer に伝える)を開始するには、結果を <font color=#009900>dispatch()</font>関数に渡します。

```javascript
dispatch(addTodo(text));
dispatch(completeTodo(index));
```

あるいは、自動的にディスパッチする紐づけされた Action Creator を作成することもできます。

```javascript
const boundAddTodo = (text) => dispatch(addTodo(text));
const boundCompleteTodo = (index) => dispatch(completeTodo(index));
```

これで、直接呼び出すことができます。

```javascript
boundAddTodo(text);
boundCompleteTodo(index);
```

## おさらいのソースコード

actions.js

```javascript
/*
 * action types の定義
 */

export const ADD_TODO = "ADD_TODO";
export const TOGGLE_TODO = "TOGGLE_TODO";
export const SET_VISIBILITY_FILTER = "SET_VISIBILITY_FILTER";

/*
 * その他の定数
 */

export const VisibilityFilters = {
  SHOW_ALL: "SHOW_ALL",
  SHOW_COMPLETED: "SHOW_COMPLETED",
  SHOW_ACTIVE: "SHOW_ACTIVE",
};

/*
 * action creators
 */

export function addTodo(text) {
  return { type: ADD_TODO, text };
}

export function toggleTodo(index) {
  return { type: TOGGLE_TODO, index };
}

export function setVisibilityFilter(filter) {
  return { type: SET_VISIBILITY_FILTER, filter };
}
```

では、これらの<font color=#FF1493>Action</font>をディスパッチ(選択、送信)したときにどのように状態(<font color=#FF8C00>Store</font>)が更新されるかを指定するために、いくつかの<font color=#4682B4> Reducers</font>を定義してみましょう。
[次へ Reducer](02Reducers.md)
