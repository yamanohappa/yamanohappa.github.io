# Redux チュートリアル Data Flow

[Read Me | Redux チュートリアル Data Flow
](https://redux.js.org/basics/data-flow)

- [<font color=#FF1493>Action</font>](01Action.md)
- [<font color=#4682B4> Reducers</font>](02Reducers.md)
- [<font color=#FF8C00>Store</font>](03Store.md)← は単一で、中に state が複数
- [Data Flow](04DataFlow.md)
- [Usage with React](05UsagewithReact.md)

---

## Redux の構成

Redux と React を利用したサンプルアプリケーションの構成  
![構成画像](2016-redux-react.png)  
Redux + React の構成イメージ

<br>
<br>

---

## Data Flow

Redux アーキテクチャは、厳密な一方向性のデータフローを中心に展開します。

これは、アプリケーション内のすべてのデータが同じライフサイクルパターンに従うことを意味し、アプリのロジックをより予測しやすく、理解しやすくします。また、データの正規化も促進されるので、同じデータの複数の独立したコピーがお互いに認識できずに終わってしまうこともありません。
それでも納得できない場合は、Motivation と The Case for Flux を読んで、一方向性のないデータフローを支持する説得力のある議論をしてください。Redux は Flux とは異なりますが、主なメリットは共通しています。

Redux アプリのデータライフサイクルは、以下の 4 つのステップに従います。

1. store.dispatch(action)を呼び出します。

アクションとは、何が起こったかを説明する平易なオブジェクトです。例えば

```javascript
 { type: 'LIKE_ARTICLE', articleId: 42 }
 { type: 'FETCH_USER_SUCCESS', response: { id: 3, name: 'Mary' } }
 { type: 'ADD_TODO', text: 'Read the Redux docs.' }
```

行動をニュースの非常に短いスニペットと考えてください。"Mary は記事 42 が好きだった "とか、"Redux のドキュメントを読む "が ToDo リストに追加されました。

store.dispatch(action)は、コンポーネントや XHR コールバックを含め、アプリ内のどこからでも、あるいはスケジュールされた間隔で呼び出すことができます。

2. Redux ストアは、あなたが与えたレデューサー関数を呼び出します。

ストアは、現在の状態ツリーとアクションの 2 つの引数をレデューサに渡します。例えば、todo アプリでは、ルートのレデューサは次のようなものを受け取るかもしれません。

```javascript
// The current application state (list of todos and chosen filter)
let previousState = {
  visibleTodoFilter: "SHOW_ALL",
  todos: [
    {
      text: "Read the docs.",
      complete: false,
    },
  ],
};

// The action being performed (adding a todo)
let action = {
  type: "ADD_TODO",
  text: "Understand the flow.",
};

// Your reducer returns the next application state
let nextState = todoApp(previousState, action);
```

減力剤は純粋な関数であることに注意してください。次の状態を計算するだけです。完全に予測可能でなければなりません。同じ入力で何度も呼び出しても同じ出力が得られます。API コールやルータ遷移のような副作用を実行してはいけません。これらはアクションがディスパッチされる前に起こるべきです。

---

Redux の仕組みがわかったところで、React アプリに接続してみましょう。

[次へ Usage with React](05UsagewithReact.md)
