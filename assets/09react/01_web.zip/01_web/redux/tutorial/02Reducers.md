# Redux チュートリアル <font color=#4682B4> Reducers</font>

[Read Me | Redux チュートリアル Reducers](https://redux.js.org/basics/reducers)

- [<font color=#FF1493>Action</font>](01Action.md)
- [<font color=#4682B4> Reducers</font>](02Reducers.md)
- [<font color=#FF8C00>Store</font>](03Store.md)← は単一で、中に state が複数
- [Data Flow](04DataFlow.md)
- [Usage with React](05UsagewithReact.md)

---

## Redux の構成

Redux と React を利用したサンプルアプリケーションの構成  
![構成画像](2016-redux-react.png)  
Redux + React の構成イメージ

<br>
<br>

---

## <font color=#4682B4> Reducers</font>

<font color=#4682B4> Reducers</font>はストアに送信された<font color=#FF1493>Action</font>に応答して、アプリケーションの状態(state)がどのように変化するかを指定します。

## State の構成を設計する

Redux では、アプリケーションの状態はすべて 1 つのオブジェクトとして格納されています。コードを書く前にその形を考えておくといいでしょう。

サンプルとして ToDo アプリでは２つ情報を保存します。

- 現在選択している Todo リストの可視状態(リストを見せるか見せないかの状態)
- ToDo リストの中身(内容＋完了かどうか)

UI の状態と同様に、いくつかのデータを状態ツリーに保存する必要があることに気づくでしょう。これは問題ありませんが、データと UI の状態を分離しておくようにしてください。

```javascript
{
    //1つめの情報(今回はUIの状態)
  visibilityFilter: 'SHOW_ALL',

    //2つめの情報(今回はデータ)
  todos: [
    {
      text: 'やること1',
      completed: true
    },
    {
      text: 'やること2',
      completed: false
    }
  ]
}
```

<br>
<br>

---

## <font color=#FF1493>Action</font>の処理

状態オブジェクト(State の構成)がどのようなものになるかが決まりましたので、そのための<font color=#4682B4> Reducers</font>を書く準備ができました。<font color=#4682B4> Reducers</font>は、前の状態(現在の状態)と<font color=#FF1493>Action</font>を受け取り、次の状態を返す純粋な関数です。

```javascript
(previousState, action) => nextState;
```

これは<font color=#009900>Array.prototype.reduce(reducer, ?initialValue)</font>に渡す type の関数なので、reducer と呼ばれています。reducer は純粋なままであることが非常に重要です。

以下<font color=#4682B4> Reducers</font>が行ってはいけないこと。

- 引数の内容の変更
- API コールやルーティングトランジションのような副作用の実行。
- <font color=#009900>Date.now()</font> や <font color=#009900>Math.random()</font> などの純粋でない関数を呼び出す。
  - ※純粋な関数とは、引数が同じなら、いつ呼ばれても同じ出力を返す関数。

まずは初期状態を指定することから始めます。Redux は、初めて未定義の状態で reducer を呼び出します。これは、アプリの初期状態を返すチャンスです。

```javascript
import { VisibilityFilters } from "./actions";

//初期状態指定
const initialState = {
  visibilityFilter: VisibilityFilters.SHOW_ALL,
  todos: [],
};

//たぶんこいつがReducer本体　現在の状態と、アクションから、次の状態を返却
function todoApp(state, action) {
  //状態が存在しない場合、状態を初期化
  if (typeof state === "undefined") {
    return initialState;
  }

  // とりあえず、アクションは一切扱わず、
  // 与えられた状態を返すだけにしておきましょう。
  return state;
}
```

todoApp 関数は、もう一つの書き方の方がコンパクトです

```javascript
function todoApp(state = initialState, action) {
  // todoApp内のifによるチェックが完結に書ける
  return state;
}
```

では、<font color=#009900>SET_VISIBILITY_FILTER</font>を処理してみましょう。必要なのは、状態の<font color=#009900>visibilityFilter</font>を変更することだけです。簡単ですね。

```javascript
import {
  SET_VISIBILITY_FILTER,
  VisibilityFilters
} from './actions'

...//略

function todoApp(state = initialState, action) {
  switch (action.type) {
    case SET_VISIBILITY_FILTER:
        //Object.assign()で第2引数以降をコピーできる
      return Object.assign({}, state, {
        visibilityFilter: action.filter
      })
    default:
      return state
  }
}
```

注意事項

1. Reducer で直接 state を変更しません。<font color=#009900>Object.assign()</font>でコピーを作成します。<font color=#009900>Object.assign(state, { visibilityFilter: action.filter })</font>も間違っています。最初の引数に空のオブジェクトを与える必要があります。  
   代わりに<font color=#009900>{ ...state, ...newState }</font>を書くように、オブジェクト拡散演算子の提案を有効にすることもできます。

2. デフォルトの場合は前の状態を返します。**未知のアクションに対しては前の状態を返すことが重要**です。

<br>
<br>

---

## その他の<font color=#FF1493>Action</font>の処理

さらに 2 つのアクションを処理する必要があります！<font color=#009900>SET_VISIBILITY_FILTER</font>で行ったように、<font color=#009900>ADD_TODO</font>と<font color=#009900>TOGGLE_TOD</font>アクションをインポートし、<font color=#009900>ADD_TODO</font>を処理するためのレデューサを拡張します。<font color=#009900>SET_VISIBILITY_FILTER</font>で行ったように、<font color=#009900>ADD_TODO</font>と<font color=#009900>TOGGLE_TODO</font>アクションをインポートし、<font color=#009900>ADD_TODO</font>を処理するためにレデューサを拡張します。(case が増えるだけ)

```javascript
import {
  ADD_TODO,
  TOGGLE_TODO,
  SET_VISIBILITY_FILTER,
  VisibilityFilters
} from './actions'

...

function todoApp(state = initialState, action) {
  switch (action.type) {
    case SET_VISIBILITY_FILTER:
      return Object.assign({}, state, {
        visibilityFilter: action.filter
      })
    case ADD_TODO:  //ここ追加
      return Object.assign({}, state, {
          //出力するtodosは現在のtodosと追加のtodoを連結したもの
        todos: [
          ...state.todos,
          {
            text: action.text,
            completed: false
          }
        ]
      })
    default:
      return state
  }
}
```

以前と同じように、ステートやそのフィールドに直接書き込むことはなく、代わりに新しいオブジェクトを返します。新しい TODO は、古い TODO を最後に 1 つの新しい項目で連結したものと同じです。新鮮な Todo はアクションからのデータを使って構築されています。

最後に<font color=#009900>TOGGLE_TODO</font>ハンドラの実装を行うこともあたりまえですよね。

```javascript
case TOGGLE_TODO:      //これも追加
  return Object.assign({}, state, {
    todos: state.todos.map((todo, index) => {
      if (index === action.index) {
        return Object.assign({}, todo, {
          completed: !todo.completed
        })
      }
      return todo
    })
  })
```

直接的な変更に頼らずに配列内の特定の項目を更新したいので、インデックスの項目以外は同じ項目で新しい配列を作成しなければなりません。このような操作を頻繁に書く場合は、immutability-helper や updeep のようなヘルパー、あるいはディープアップデートをネイティブでサポートしている Immutable のようなライブラリを使うのが良いでしょう。ただ、最初にクローンを作成しない限り、ステート内の何かに代入しないことを覚えておいてください。

<br>
<br>

---

## <font color=#4682B4> Reducers</font>の分割

これまでのコードは次のとおりです。それはかなり冗長です：

```javascript
function todoApp(state = initialState, action) {
  switch (action.type) {
    case SET_VISIBILITY_FILTER:
      return Object.assign({}, state, {
        visibilityFilter: action.filter,
      });
    case ADD_TODO:
      return Object.assign({}, state, {
        todos: [
          ...state.todos,
          {
            text: action.text,
            completed: false,
          },
        ],
      });
    case TOGGLE_TODO:
      return Object.assign({}, state, {
        todos: state.todos.map((todo, index) => {
          if (index === action.index) {
            return Object.assign({}, todo, {
              completed: !todo.completed,
            });
          }
          return todo;
        }),
      });
    default:
      return state;
  }
}
```

もっとわかりやすくする方法はないのでしょうか？<font color=#009900>todos</font> と <font color=#009900>visibilityFilter</font> は完全に独立して更新されているような気がします。状態フィールドが互いに依存している場合もあり、より配慮が必要な場合もありますが、今回の場合は簡単に <font color=#009900>todos</font> の更新を別の関数に分けることができます。

```javascript
function todos(state = [], action) {
  switch (action.type) {
    case ADD_TODO:
      return [
        ...state,
        {
          text: action.text,
          completed: false,
        },
      ];
    case TOGGLE_TODO:
      return state.map((todo, index) => {
        if (index === action.index) {
          return Object.assign({}, todo, {
            completed: !todo.completed,
          });
        }
        return todo;
      });
    default:
      return state;
  }
}

function todoApp(state = initialState, action) {
  switch (action.type) {
    case SET_VISIBILITY_FILTER:
      return Object.assign({}, state, {
        visibilityFilter: action.filter,
      });
    case ADD_TODO:
      return Object.assign({}, state, {
        todos: todos(state.todos, action),
      });
    case TOGGLE_TODO:
      return Object.assign({}, state, {
        todos: todos(state.todos, action),
      });
    default:
      return state;
  }
}
```

<br>
<br>

<font color=#009900>todos()</font> はステートも受け付けていますが、ステートは配列であることに注意してください。これで <font color=#009900>todoApp()</font> は <font color=#009900>todos()</font> に状態を管理するためのスライスだけを与え、<font color=#009900>todos()</font> はそのスライスだけを更新する方法を知っています。これは reducer composition と呼ばれるもので、Redux アプリを構築する際の基本的なパターンです。

レデューサの構成をもっと探ってみましょう。<font color=#009900>visibilityFilter</font>だけを管理しているレデューサも抽出できるのでしょうか？.....できます!

```javascript
const { SHOW_ALL } = VisibilityFilters;
```

```javascript
function visibilityFilter(state = SHOW_ALL, action) {
  switch (action.type) {
    case SET_VISIBILITY_FILTER:
      return action.filter;
    default:
      return state;
  }
}
```

あとは、状態の一部を管理しているレデューサーを呼び出して一つのオブジェクトにまとめる機能として、メインのレデューサーを書き換えればいいのです。また、完全な初期状態を知る必要もありません。子レデューサは、最初に未定義の状態が与えられたときに、その初期状態を返すだけで十分です。

```javascript
function todos(state = [], action) {
  switch (action.type) {
    case ADD_TODO:
      return [
        ...state,
        {
          text: action.text,
          completed: false,
        },
      ];
    case TOGGLE_TODO:
      return state.map((todo, index) => {
        if (index === action.index) {
          return Object.assign({}, todo, {
            completed: !todo.completed,
          });
        }
        return todo;
      });
    default:
      return state;
  }
}

function visibilityFilter(state = SHOW_ALL, action) {
  switch (action.type) {
    case SET_VISIBILITY_FILTER:
      return action.filter;
    default:
      return state;
  }
}

function todoApp(state = {}, action) {
  return {
    visibilityFilter: visibilityFilter(state.visibilityFilter, action),
    todos: todos(state.todos, action),
  };
}
```

これらのレデューサは、それぞれグローバルステートの一部を管理していることに注意してください。状態パラメータは各レデューサごとに異なり、それが管理する状態の一部に対応しています。  
これはもう、いい感じですね! アプリが大きくなったら、レデューサーを別のファイルに分割して、完全に独立して別のデータ領域を管理するようにしています。

最後に、Redux は combineReducers() と呼ばれるユーティリティを提供しており、上の todoApp が現在行っているのと同じ定型的なロジックを実行します。その助けを借りて、todoApp を次のように書き換えることができます。

```javascript
import { combineReducers } from "redux";

const todoApp = combineReducers({
  visibilityFilter,
  todos,
});

export default todoApp;
```

これは次と同等であることに注意してください。

```javascript
export default function todoApp(state = {}, action) {
  return {
    visibilityFilter: visibilityFilter(state.visibilityFilter, action),
    todos: todos(state.todos, action),
  };
}
```

また、異なるキーを与えたり、異なる関数を呼び出したりすることもできます。これら 2 つの方法は、結合されたレデューサの書き方に相当します。

```javascript
const reducer = combineReducers({
  a: doSomethingWithA,
  b: processB,
  c: c,
});
```

```javascript
function reducer(state = {}, action) {
  return {
    a: doSomethingWithA(state.a, action),
    b: processB(state.b, action),
    c: c(state.c, action),
  };
}
```

<font color=#009900>combineReducers()</font>
が行うのは、キーに応じて選択された状態のスライスを持つレデューサを呼び出し、その結果を再び単一のオブジェクトに結合する関数を生成するだけです。これは魔法ではありません。また、他のレデューサと同様に、
<font color=#009900>combineReducers()</font>
は、提供されたすべてのレデューサが状態を変更しない場合、新しいオブジェクトを生成しません。

<br>
<br>

---

## ソースコード

これまでのコードは以下の通りです。かなり冗長です。

reducers.js

```javascript
import { combineReducers } from "redux";
import {
  ADD_TODO,
  TOGGLE_TODO,
  SET_VISIBILITY_FILTER,
  VisibilityFilters,
} from "./actions";
const { SHOW_ALL } = VisibilityFilters;

function visibilityFilter(state = SHOW_ALL, action) {
  switch (action.type) {
    case SET_VISIBILITY_FILTER:
      return action.filter;
    default:
      return state;
  }
}

function todos(state = [], action) {
  switch (action.type) {
    case ADD_TODO:
      return [
        ...state,
        {
          text: action.text,
          completed: false,
        },
      ];
    case TOGGLE_TODO:
      return state.map((todo, index) => {
        if (index === action.index) {
          return Object.assign({}, todo, {
            completed: !todo.completed,
          });
        }
        return todo;
      });
    default:
      return state;
  }
}

const todoApp = combineReducers({
  visibilityFilter,
  todos,
});

export default todoApp;
```

次に、状態(state)を保持する Redux <font color=#FF8C00>Store</font>を作成し、アクションをディスパッチする際に <font color=#4682B4> Reducers</font> を呼び出す処理を行う方法を探っていきます。
[次へ Store](03Store.md)
