# Redux について

[Read Me · Redux のチュートリアル](http://redux.js.org/)に対しての解説

[元サイト](https://laboradian.com/tried-react-redux-tutorial/#1)

---

## Redux の構成

Redux と React を使ったこのサンプルアプリケーションの構成
![構成画像](2016-redux-react.png)
Redux + React の構成イメージ

action、reducre, state の関係を以下に示す
![構成画像](actions-and-reducers-v1.0.0.min_.png)  
action、reducre, state の関係

1. アプリケーションとして保持する値(state)のそれぞれに対して、1 つずつ reducer を用意します（1:1 対応）。つまり、ある 1 つの値を更新する処理は複数あっても 1 つの reducre にまとめます。その中のどの処理を実行するかは、reducre に渡される action 引数の type 属性で判別します。

2. action は、Container component 側から store.dispatch()メソッドを実行する際に渡すオブジェクトですが、store.dispatch()メソッドの内部では 1 つ 1 つの reducer に渡されています。action と reducre は 1:1 対応であるとは限りません。複数の action が 1 つの reducer で処理されることもありますので、N:1 対応となります。

---

## Action と Action Creator

- Container 内の dispatch を実行するところで引数として使用する。
- アプリケーション開発者が用意する。

### Action

- JavaScript のオブジェクトである。
- 何が起きるか？を記述する。
- type プロパティは必須。
- type プロパティ以外に、どのようなプロパティを用意するのがよいかについては以下が参考になる。
- [acdlite/flux-standard-action: A human-friendly standard for Flux action objects.](https://github.com/acdlite/flux-standard-action)

### Action Creators

- Action を返す関数。

---

## Reducers

- state と action を受け取って、新しい state を返す関数。
- アプリケーション開発者が用意する。
- 副作用があってはいけない。
- デフォルト引数を使えば、文字通りそれが初期値となる。
- 複数作ることができる。
- その場合は、combineReducers() でまとめることができる。

---

## Store

createStore()に、Reducer を渡して作成する。
