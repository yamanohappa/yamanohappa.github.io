# Redux とは

Redux は JavaScript アプリのための予測可能な状態コンテナです

react は見た目、Redux は状態を管理する

## Redux の追加方法

```powershell
# NPM
npm install redux
#または
# Yarn
yarn add redux
```

## 1 から React Redux アプリの作成を行う場合

Redux Toolkit や React Redux と React コンポーネントの連携を活用した「Create React App」の公式 Redux+JS テンプレートの利用

```powershell
npx create-react-app my-app --template redux
```

<br>
